$.getJSON("/current", function(data){
         if(data==null){
          window.location.href="http://3.130.238.73/dologin"
         }
             });

function Settings(){
                window.location.href="http://3.130.238.73/settings"
    }
function Rankings(){
                window.location.href="http://3.130.238.73/rankings"
    }
function Subir_contenido(){
                window.location.href="http://3.130.238.73/subir_contenido"
    }
function Jugar(){
                window.location.href="http://3.130.238.73/juego"
    }
